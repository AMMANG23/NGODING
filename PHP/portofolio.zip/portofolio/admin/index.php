<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>my portofolio</title>
  <link rel="stylesheet" href="css/bootstrap.css">
</head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.0/font/bootstrap-icons.css">
<body class = "bg-alert alert-primary">
    <div class="container">
<?php
$connect = mysqli_connect('127.0.0.1', 'root', '', 'portofolio');
$select = mysqli_query($connect, "SELECT * FROM message");
$number =  0;
while($message = mysqli_fetch_array($select)){ 
    $number += 1;
    ?>
<table class="table-info">
<thead>
    <tr>
      <td class="text-danger" scope="col"><?php echo $number ?>. Pesan Dari : <?php echo $message['name'] ?></td>
      <td class="text-danger" scope="col"> >>> <?php echo $message['message'] ?></td>
    </tr>
  </thead>
</table>
<?php
}
?>
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>
